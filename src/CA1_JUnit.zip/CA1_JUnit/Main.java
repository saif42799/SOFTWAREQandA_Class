package CA1_JUnit;

public class Main {
    public static void main(String[] args) {

    }
}
